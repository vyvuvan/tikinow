package com.ifv.demo.service;

public interface UserService {
}
