package com.ifv.demo.service.impl;

import com.ifv.demo.service.UserService;

public class UserServiceImpl implements UserService {
    
    
}
